// Array de palavras para o jogo da forca
const words = ['C', 'Java', 'Python', 'JavaScript', 'PHP', 'Web', 'Html', 'Css', 'Mysql', 'Oracle', 'Postgresql'];

// Palavra selecionada para o jogo atual
let selectedWord = '';

// Array para armazenar as letras adivinhadas corretamente
let guessedWord = [];

// Número de tentativas de adivinhação incorretas
let incorrectGuesses = 0;

// Número máximo de tentativas de adivinhação incorretas permitidas
let maxIncorrectGuesses = 10;

// Flag para verificar se o jogo acabou
let isGameOver = false;

// Função para inicializar o jogo
function initializeGame() {
  // Limpa a mensagem de resultado do jogo
  const gameResult = document.getElementById('gameResult');
  gameResult.textContent = '';

  // Seleciona uma palavra aleatória do array de palavras
  selectedWord = words[Math.floor(Math.random() * words.length)];

  // Preenche o array de letras adivinhadas com underscores
  guessedWord = new Array(selectedWord.length).fill('_');

  // Reinicia o número de tentativas de adivinhação incorretas
  incorrectGuesses = 0;

  // Reinicia a flag do jogo acabado
  isGameOver = false;

  // Atualiza a exibição do jogo
  updateDisplay();
}

// Função para adivinhar uma letra
function guessLetter(event) {
  event.preventDefault(); // Evita o comportamento padrão de recarregar a página
  if (isGameOver) return; // Se o jogo acabou, não faça nada

  const guessInput = document.getElementById('guessInput');
  const letter = guessInput.value.toUpperCase();
  guessInput.value = '';

  if (!/^[A-Z]$/.test(letter)) {
    alert('Por favor, insira uma letra válida.');
    return;
  }

  if (guessedWord.includes(letter)) {
    alert('Você já usou esta letra.');
    return;
  }

  let isCorrectGuess = false;
  for (let i = 0; i < selectedWord.length; i++) {
    if (selectedWord[i].toUpperCase() === letter) {
      guessedWord[i] = letter;
      isCorrectGuess = true;
    }
  }

  if (!isCorrectGuess) {
    incorrectGuesses++;
  }

  updateDisplay();
}

// Função para atualizar a exibição do jogo
function updateDisplay() {
  const wordDisplay = document.getElementById('wordDisplay');
  wordDisplay.textContent = guessedWord.join(' '); // Exibe as letras adivinhadas

  const hangmanDrawing = document.getElementById('hangmanDrawing');
  hangmanDrawing.innerHTML = drawHangman(incorrectGuesses); // Desenha a forca

  const chancesLeft = document.getElementById('chancesLeft');
  chancesLeft.textContent = `Número de tentativas restantes: ${maxIncorrectGuesses - incorrectGuesses}`; // Exibe as tentativas restantes

  checkGameOver(); // Verifica se o jogo acabou
}

// Função para desenhar a forca
function drawHangman(incorrectGuesses) {
  // Como não estamos desenhando nada, retornamos uma string vazia
  return '';
}

// Função para verificar se o jogo acabou
function checkGameOver() {
  if (guessedWord.join('') === selectedWord.toUpperCase()) { // Se a palavra foi totalmente adivinhada
    endGame('PARABÉNS VOCÊ ACERTOU!!!!');
  } else if (incorrectGuesses >= maxIncorrectGuesses) { // Se o número máximo de tentativas foi atingido
    endGame(`NÃO FOI DESSA. A palavra correta era "${selectedWord}".`);
  }
}

// Função para finalizar o jogo
function endGame(message) {
  isGameOver = true; // Define a flag de jogo acabado como verdadeira
  const gameResult = document.getElementById('gameResult');
  gameResult.textContent = message; // Exibe a mensagem de resultado do jogo
}

// Função para reiniciar o jogo
function restartGame() {
  initializeGame(); // Inicializa o jogo novamente
}

initializeGame(); // Inicializa o jogo ao carregar a página
