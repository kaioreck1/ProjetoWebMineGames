// Verifica se o token de autenticação está presente no localStorage
if (localStorage.getItem("token") == null) {
  // Se não estiver presente, exibe um alerta e redireciona para a página de login
  alert("Você precisa estar logado para acessar essa página");
  window.location.href = "./assets/html/singin.html";
}

// Obtém os dados do usuário logado do localStorage
const userLogado = JSON.parse(localStorage.getItem("userLogado"));

// Seleciona o elemento com o id "logado" e exibe uma mensagem de boas-vindas
const logado = document.querySelector("#logado");
logado.innerHTML = `Olá ${userLogado.nome}`;

// Função para sair/logout do sistema
function sair() {
  // Remove o token de autenticação e os dados do usuário do localStorage
  localStorage.removeItem("token");
  localStorage.removeItem("userLogado");
  // Redireciona para a página de login
  window.location.href = "./assets/html/signin.html";
}
