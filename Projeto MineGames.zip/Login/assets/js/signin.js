// Seleciona o botão de exibir/esconder senha
let btn = document.querySelector('.fa-eye')

// Adiciona um evento de clique ao botão
btn.addEventListener('click', () => {
  // Seleciona o input da senha
  let inputSenha = document.querySelector('#senha')

  // Verifica se o tipo do input é senha
  if (inputSenha.getAttribute('type') == 'password') {
    // Se for, altera para texto
    inputSenha.setAttribute('type', 'text')
  } else {
    // Caso contrário, altera para senha
    inputSenha.setAttribute('type', 'password')
  }
})

// Função para realizar o login
function entrar() {
  // Seleciona os elementos do formulário de login
  let usuario = document.querySelector('#usuario')
  let userLabel = document.querySelector('#userLabel')
  let senha = document.querySelector('#senha')
  let senhaLabel = document.querySelector('#senhaLabel')
  let msgError = document.querySelector('#msgError')
  let listaUser = []

  // Objeto para armazenar os dados do usuário válido
  let userValid = {
    nome: '',
    user: '',
    senha: ''
  }

  // Obtém a lista de usuários do localStorage
  listaUser = JSON.parse(localStorage.getItem('listaUser'))

  // Itera sobre a lista de usuários para encontrar o usuário e senha correspondentes
  listaUser.forEach((item) => {
    if (usuario.value == item.userCad && senha.value == item.senhaCad) {

      userValid = {
        nome: item.nomeCad,
        user: item.userCad,
        senha: item.senhaCad
      }

    }
  })

  // Verifica se o usuário e senha informados correspondem aos dados armazenados
  if (usuario.value == userValid.user && senha.value == userValid.senha) {
    // Se correspondem, redireciona para a página do menu

    // Gera um token de autenticação aleatório
    let mathRandom = Math.random().toString(16).substr(2)
    let token = mathRandom + mathRandom

    // Armazena o token e os dados do usuário logado no localStorage
    localStorage.setItem('token', token)
    localStorage.setItem('userLogado', JSON.stringify(userValid))

    // Redireciona para a página do menu
    window.location.href = '../../../menu.html'
  } else {
    // Se não correspondem, exibe uma mensagem de erro

    // Altera o estilo dos elementos para indicar erro
    userLabel.setAttribute('style', 'color: red')
    usuario.setAttribute('style', 'border-color: red')
    senhaLabel.setAttribute('style', 'color: red')
    senha.setAttribute('style', 'border-color: red')
    msgError.setAttribute('style', 'display: block')
    msgError.innerHTML = 'Usuário ou senha incorretos'

    // Define o foco no campo de usuário para facilitar a correção
    usuario.focus()
  }

}
