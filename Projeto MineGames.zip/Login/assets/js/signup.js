// Seleciona o botão de exibir/esconder senha
let btn = document.querySelector('#verSenha')
let btnConfirm = document.querySelector('#verConfirmSenha')

// Seleciona os elementos do formulário de cadastro
let nome = document.querySelector('#nome')
let labelNome = document.querySelector('#labelNome')
let validNome = false

let usuario = document.querySelector('#usuario')
let labelUsuario = document.querySelector('#labelUsuario')
let validUsuario = false

let senha = document.querySelector('#senha')
let labelSenha = document.querySelector('#labelSenha')
let validSenha = false

let confirmSenha = document.querySelector('#confirmSenha')
let labelConfirmSenha = document.querySelector('#labelConfirmSenha')
let validConfirmSenha = false

let msgError = document.querySelector('#msgError')
let msgSuccess = document.querySelector('#msgSuccess')

// Adiciona um evento de tecla solta ao campo de nome
nome.addEventListener('keyup', () => {
  // Verifica se o tamanho do nome é menor ou igual a 2
  if (nome.value.length <= 2) {
    // Se for, exibe uma mensagem de erro
    labelNome.setAttribute('style', 'color: red')
    labelNome.innerHTML = 'Nome *Insira no mínimo 3 caracteres'
    nome.setAttribute('style', 'border-color: red')
    validNome = false
  } else {
    // Caso contrário, exibe uma mensagem de sucesso
    labelNome.setAttribute('style', 'color: green')
    labelNome.innerHTML = 'Nome'
    nome.setAttribute('style', 'border-color: green')
    validNome = true
  }
})

// Adiciona um evento de tecla solta ao campo de usuário
usuario.addEventListener('keyup', () => {
  // Verifica se o tamanho do nome é menor ou igual a 4
  if (usuario.value.length <= 4) {
    // Se for, exibe uma mensagem de erro
    labelUsuario.setAttribute('style', 'color: red')
    labelUsuario.innerHTML = 'Usuário *Insira no mínimo 5 caracteres'
    usuario.setAttribute('style', 'border-color: red')
    validUsuario = false
  } else {
    // Caso contrário, exibe uma mensagem de sucesso
    labelUsuario.setAttribute('style', 'color: green')
    labelUsuario.innerHTML = 'Usuário'
    usuario.setAttribute('style', 'border-color: green')
    validUsuario = true
  }
})

// Adiciona um evento de tecla solta ao campo de senha
senha.addEventListener('keyup', () => {
  // Verifica se o tamanho da senha é menor ou igual a 5
  if (senha.value.length <= 5) {
    // Se for, exibe uma mensagem de erro
    labelSenha.setAttribute('style', 'color: red')
    labelSenha.innerHTML = 'Senha *Insira no mínimo 6 caracteres'
    senha.setAttribute('style', 'border-color: red')
    validSenha = false
  } else {
    // Caso contrário, exibe uma mensagem de sucesso
    labelSenha.setAttribute('style', 'color: green')
    labelSenha.innerHTML = 'Senha'
    senha.setAttribute('style', 'border-color: green')
    validSenha = true
  }
})

// Adiciona um evento de tecla solta ao campo de confirmação de senha
confirmSenha.addEventListener('keyup', () => {
  // Verifica se a senha e a confirmação de senha são diferentes
  if (senha.value != confirmSenha.value) {
    // Se forem, exibe uma mensagem de erro
    labelConfirmSenha.setAttribute('style', 'color: red')
    labelConfirmSenha.innerHTML = 'Confirmar Senha *As senhas não conferem'
    confirmSenha.setAttribute('style', 'border-color: red')
    validConfirmSenha = false
  } else {
    // Caso contrário, exibe uma mensagem de sucesso
    labelConfirmSenha.setAttribute('style', 'color: green')
    labelConfirmSenha.innerHTML = 'Confirmar Senha'
    confirmSenha.setAttribute('style', 'border-color: green')
    validConfirmSenha = true
  }
})

// Função para realizar o cadastro
function cadastrar() {
  // Verifica se todos os campos foram preenchidos corretamente
  if (validNome && validUsuario && validSenha && validConfirmSenha) {
    // Obtém a lista de usuários do localStorage
    let listaUser = JSON.parse(localStorage.getItem('listaUser') || '[]')

    // Adiciona o novo usuário à lista
    listaUser.push(
      {
        nomeCad: nome.value,
        userCad: usuario.value,
        senhaCad: senha.value
      }
    )

    // Atualiza a lista de usuários no localStorage
    localStorage.setItem('listaUser', JSON.stringify(listaUser))

    // Exibe uma mensagem de sucesso
    msgSuccess.setAttribute('style', 'display: block')
    msgSuccess.innerHTML = '<strong>Cadastrando usuário...</strong>'
    msgError.setAttribute('style', 'display: none')
    msgError.innerHTML = ''

    // Redireciona para a página de login após 3 segundos
    setTimeout(() => {
      window.location.href = '../html/signin.html'
    }, 3000)

  } else {
    // Se algum campo não estiver preenchido corretamente, exibe uma mensagem de erro
    msgError.setAttribute('style', 'display: block')
    msgError.innerHTML = '<strong>Preencha todos os campos corretamente antes de cadastrar</strong>'
    msgSuccess.innerHTML = ''
    msgSuccess.setAttribute('style', 'display: none')
  }
}

// Adiciona um evento de clique ao botão de exibir/esconder senha
btn.addEventListener('click', () => {
  // Seleciona o input da senha
  let inputSenha = document.querySelector('#senha')

  // Verifica se o tipo do input é senha
  if (inputSenha.getAttribute('type') == 'password') {
    // Se for, altera para texto
    inputSenha.setAttribute('type', 'text')
  } else {
    // Caso contrário, altera para senha
    inputSenha.setAttribute('type', 'password')
  }
})

// Adiciona um evento de clique ao botão de exibir/esconder confirmação de senha
btnConfirm.addEventListener('click', () => {
  // Seleciona o input da confirmação de senha
  let inputConfirmSenha = document.querySelector('#confirmSenha')

  // Verifica se o tipo do input é senha
  if (inputConfirmSenha.getAttribute('type') == 'password') {
    // Se for, altera para texto
    inputConfirmSenha.setAttribute('type', 'text')
  } else {
    // Caso contrário, altera para senha
    inputConfirmSenha.setAttribute('type', 'password')
  }
})
