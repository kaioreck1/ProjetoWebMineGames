// Define as constantes para o canvas e o contexto
const canvas = document.getElementById("gameCanvas");
const context = canvas.getContext("2d");

// Define o tamanho da caixa e as dimensões do canvas
const box = 20;
const canvasWidth = canvas.width;
const canvasHeight = canvas.height;

// Inicializa a cobra e a comida
let snake = [{ x: 200, y: 200 }];
let food = { x: 0, y: 0 };

// Define as variáveis para controlar a direção da cobra
let dx = 0;
let dy = 0;

// Define o intervalo do jogo e se o jogo acabou
let gameInterval;
let isGameOver = false;

// Define a pontuação inicial
let score = 0;

// Função para obter uma posição aleatória no canvas
function getRandomPosition() {
  return Math.floor(Math.random() * (canvasWidth / box)) * box;
}

// Desenha a cobra
function drawSnake() {
  snake.forEach(segment => {
    context.fillStyle = "green";
    context.fillRect(segment.x, segment.y, box, box);
  });
}

// Desenha a comida
function drawFood() {
  context.fillStyle = "red";
  context.fillRect(food.x, food.y, box, box);
}

// Move a cobra
function moveSnake() {
  const head = { x: snake[0].x + dx, y: snake[0].y + dy };
  snake.unshift(head);

  // Verifica se a cobra comeu a comida
  if (head.x === food.x && head.y === food.y) {
    generateFood();
    score++; // Incrementa a pontuação ao comer a comida
  } else {
    snake.pop();
  }

  // Verifica se o jogo acabou
  if (head.x < 0 || head.x >= canvasWidth || head.y < 0 || head.y >= canvasHeight || isSnakeColliding()) {
    endGame();
  }
}

// Gera a comida em uma posição aleatória
function generateFood() {
  food.x = getRandomPosition();
  food.y = getRandomPosition();
}

// Função principal do jogo
function main() {
  context.clearRect(0, 0, canvasWidth, canvasHeight);
  drawSnake();
  drawFood();
  moveSnake();
  // Atualiza a pontuação exibida na página
  document.getElementById("score").innerText = score;
}

// Inicia o jogo
function startGame() {
  snake = [{ x: 200, y: 200 }];
  food = { x: getRandomPosition(), y: getRandomPosition() };
  dx = 0;
  dy = 0;
  isGameOver = false;
  score = 0; // Reinicia a pontuação ao iniciar o jogo
  document.getElementById("score").innerText = score; // Atualiza a pontuação exibida na página
  gameInterval = setInterval(main, 100);
  document.getElementById("restartButton").style.display = "none";
}

// Finaliza o jogo
function endGame() {
  clearInterval(gameInterval);
  isGameOver = true;
  document.getElementById("restartButton").style.display = "block";
}

// Reinicia o jogo
function restartGame() {
  startGame();
}

// Verifica se a cobra colidiu com ela mesma
function isSnakeColliding() {
  const head = snake[0];
  for (let i = 1; i < snake.length; i++) {
    if (head.x === snake[i].x && head.y === snake[i].y) {
      return true;
    }
  }
  return false;
}

// Captura os eventos de teclado para controlar a direção da cobra
document.addEventListener("keydown", event => {
  if (isGameOver) return;

  const keyPressed = event.key;
  if (keyPressed === "ArrowUp" && dy === 0) {
    dy = -box;
    dx = 0;
  }
  if (keyPressed === "ArrowDown" && dy === 0) {
    dy = box;
    dx = 0;
  }
  if (keyPressed === "ArrowLeft" && dx === 0) {
    dy = 0;
    dx = -box;
  }
  if (keyPressed === "ArrowRight" && dx === 0) {
    dy = 0;
    dx = box;
  }
});

startGame(); // Inicia o jogo quando a página é carregada
