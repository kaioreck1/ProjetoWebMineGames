// Obtém o elemento canvas e seu contexto
const canvas = document.getElementById("gameCanvas");
const context = canvas.getContext("2d");

// Variáveis para o carro
let carX = canvas.width / 2;
const carWidth = 40;
const carHeight = 80;
const carSpeed = 5;

// Array para armazenar os obstáculos
let obstacles = [];
const obstacleWidth = 50;
const obstacleHeight = 50;
const obstacleSpeed = 3;
const obstacleInterval = 1000; // Intervalo de tempo para gerar obstáculos
let lastObstacleTime = 0;

// Flag para verificar se o jogo acabou
let isGameOver = false;

// Adiciona um evento de teclado para mover o carro
document.addEventListener("keydown", moveCar);

// Desenha o carro na tela
function drawCar() {
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.fillStyle = "blue";
  context.fillRect(carX, canvas.height - carHeight - 10, carWidth, carHeight);
}

// Desenha os obstáculos na tela
function drawObstacles() {
  context.fillStyle = "red";
  obstacles.forEach(function(obstacle) {
    context.fillRect(obstacle.x, obstacle.y, obstacleWidth, obstacleHeight);
  });
}

// Move os obstáculos para baixo na tela
function moveObstacles() {
  obstacles.forEach(function(obstacle) {
    obstacle.y += obstacleSpeed;
  });
}

// Gera um novo obstáculo em uma posição aleatória na parte superior da tela
function generateObstacle() {
  const obstacleX = Math.random() * (canvas.width - obstacleWidth);
  obstacles.push({ x: obstacleX, y: 0 });
}

// Verifica colisão entre o carro e os obstáculos
function checkCollision() {
  for (let i = 0; i < obstacles.length; i++) {
    if (carX < obstacles[i].x + obstacleWidth &&
      carX + carWidth > obstacles[i].x &&
      canvas.height - carHeight - 10 < obstacles[i].y + obstacleHeight &&
      canvas.height - carHeight - 10 + carHeight > obstacles[i].y) {
      return true;
    }
  }
  return false;
}

// Move o carro com as teclas de seta esquerda e direita
function moveCar(event) {
  if (!isGameOver) {
    if (event.key === "ArrowLeft" && carX > 0) {
      carX -= carSpeed;
    } else if (event.key === "ArrowRight" && carX < canvas.width - carWidth) {
      carX += carSpeed;
    }
  }
}

// Reinicia o jogo
function restartGame() {
  isGameOver = false;
  carX = canvas.width / 2;
  obstacles = [];
  lastObstacleTime = 0;
  // Esconde o botão de reinício
  document.getElementById("restartButton").style.display = "none";
  // Inicia a atualização da área do jogo
  updateGameArea();
}

// Função principal para atualizar a área do jogo
function updateGameArea() {
  if (!isGameOver) {
    drawCar();
    drawObstacles();
    moveObstacles();

    // Gera um novo obstáculo se o intervalo de tempo passou
    if (Date.now() - lastObstacleTime > obstacleInterval) {
      generateObstacle();
      lastObstacleTime = Date.now();
    }

    // Verifica colisões
    if (checkCollision()) {
      isGameOver = true;
      alert("Game Over!");
      // Exibe o botão de reinício
      document.getElementById("restartButton").style.display = "block";
    }

    // Solicita a próxima atualização da área do jogo
    requestAnimationFrame(updateGameArea);
  }
}

// Inicia a atualização da área do jogo
updateGameArea();
