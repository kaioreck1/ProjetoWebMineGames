document.addEventListener('DOMContentLoaded', function() {
  // Seleciona o elemento com a classe 'board'
  const board = document.querySelector('.board');

  // Define o jogador atual como 'X' e o status do vencedor como falso
  let currentPlayer = 'X';
  let winner = false;

  // Combinações vencedoras possíveis no jogo da velha
  const winningCombos = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
  ];

  // Array para armazenar o estado das células
  const cells = Array.from({ length: 9 });

  // Função para inicializar o jogo
  function init() {
    // Cria uma célula para cada elemento do array 'cells'
    cells.forEach((_, index) => {
      const cell = document.createElement('div');
      cell.classList.add('cell'); // Adiciona a classe 'cell' à célula
      cell.dataset.index = index; // Define o atributo 'data-index' com o índice da célula
      cell.addEventListener('click', handleClick); // Adiciona um evento de clique à célula
      board.appendChild(cell); // Adiciona a célula ao tabuleiro
    });
  }

  // Função para lidar com o clique em uma célula
  function handleClick() {
    // Se já houver um vencedor, retorna
    if (winner) return;

    // Obtém o índice da célula clicada
    const cellIndex = parseInt(this.dataset.index);

    // Se a célula já estiver preenchida, retorna
    if (cells[cellIndex]) return;

    // Define o valor da célula como o jogador atual
    cells[cellIndex] = currentPlayer;
    this.textContent = currentPlayer;

    // Verifica se há um vencedor após cada jogada
    if (checkWinner()) {
      winner = true; // Define o status do vencedor como verdadeiro
      alert(`Jogador ${currentPlayer} vence!`); // Exibe uma mensagem de vitória
      return;
    }

    // Se todas as células estiverem preenchidas e não houver vencedor, declara empate
    if (cells.every(cell => cell !== undefined)) {
      alert('Empate!');
      return;
    }

    // Alterna o jogador atual entre 'X' e 'O'
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  }

  // Função para verificar se há um vencedor
  function checkWinner() {
    // Verifica se alguma das combinações vencedoras foi alcançada pelo jogador atual
    return winningCombos.some(combo => {
      return combo.every(index => cells[index] === currentPlayer);
    });
  }

  // Função para reiniciar o jogo
  function restartGame() {
    cells.fill(undefined); // Reinicia o array de células
    winner = false; // Reinicia o status de vencedor
    currentPlayer = 'X'; // Reinicia o jogador atual para 'X'
    board.innerHTML = ''; // Limpa o tabuleiro
    init(); // Reinicia o jogo
  }

  // Inicializa o jogo ao carregar o conteúdo da página
  init();

  // Cria um botão de reinício e o adiciona ao final do corpo do documento
  const restartButton = document.createElement('button');
  restartButton.textContent = 'Reiniciar'; // Define o texto do botão como 'Reiniciar'
  restartButton.style.backgroundColor = '#000'; // Define a cor de fundo do botão como preta
  restartButton.style.color = '#fff'; // Define a cor do texto do botão como branca
  restartButton.style.display = 'block'; // Exibe o botão como bloco para alinhamento
  restartButton.style.margin = '20px auto'; // Define margens superior e inferior como 20px e alinha automaticamente
  restartButton.style.padding = '10px'; // Adiciona um pouco de espaço interno ao botão
  restartButton.style.border = 'none'; // Remove a borda do botão
  restartButton.style.borderRadius = '5px'; // Adiciona bordas arredondadas ao botão
  restartButton.addEventListener('click', restartGame); // Adiciona um evento de clique ao botão
  document.body.appendChild(restartButton); // Adiciona o botão ao final do corpo do documento
});
